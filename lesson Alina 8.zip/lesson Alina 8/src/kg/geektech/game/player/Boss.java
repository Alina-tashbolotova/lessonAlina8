package kg.geektech.game.player;

public class Boss extends GameEntity {
    public Boss(int health, int damage) {
        super(health, damage);
    }

}
