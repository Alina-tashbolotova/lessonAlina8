package kg.geektech.game.player;

public interface HavingSuperAbility {
    void applySuperAbility(Boss boss, Hero[] heroes);
}
